There are five files named J22Rank5Polytopes, HS2Rank5Polytopes, 2HS2Rank5Polytopes, McL2Rank5Polytopes and He2Rank5Polytopes. 
In each of these files there is a sequence denoted C, with C[i], the ith member of the sequence, corresponding to C[i], as listed in the paper. 
For example, in J22Rank5Polytopes, C is a sequence of length 2 with C[1] and C[2] each being a sequence of length 5, giving t1, t2, t3, t4, t5 (in that order).
The ti are given as permutations - the permutation degrees for J_2:2, HS:2, 2.HS.2, McL:2 and He:2 are, respectively, 100,100, 1408, 275, 2058.